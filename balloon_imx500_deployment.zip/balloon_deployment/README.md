# Balloon Detection Model for IMX500

## Model Details
- Model: YOLOv5n (INT8 Quantized)
- Input Size: 320x320x3 (RGB)
- Input Type: uint8
- Model Size: 1.88 MB
- Classes: red_balloon (0), blue_balloon (1)

## Performance
- mAP@0.5: 0.985
- mAP@0.5:0.95: 0.743
- Precision: 0.952
- Recall: 0.964

## Files
- balloon_model_imx500.tflite: INT8 quantized model for IMX500
- model_info.json: Model metadata
- training_results.png: Training graphs
- confusion_matrix.png: Class confusion matrix

## Usage
Upload balloon_model_imx500.tflite to IMX500 camera module.
